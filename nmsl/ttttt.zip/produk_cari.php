<form method="post" action="produk_jumpa.php">
    <!-- PAPAR BORANG CARIAN -->
     Carian Produk:<br>
     <input type="text" name="carian" size="15%" autofocus>
     <br><br>
     <!-- KLIK PADA BUTANG CARI -->
      <button type="submit" name="cari">CARI</button>
</form>